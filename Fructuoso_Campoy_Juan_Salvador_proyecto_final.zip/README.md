Proyecto final de Grado en Desarrollo de Aplicaciones Web, creado por Juan Salvador Fructuoso Campoy.

El proyecto consiste en la elaboración de un TPV (Terminal de Punto de Venta) para un centro capilar específico situado en Totana, llamado Salud Capilar Hair Deluxe.

El repositorio de GitHub se encuentra en el siguiente enlace: https://github.com/JuanSalvadorFructuosoCampoy/proyecto
